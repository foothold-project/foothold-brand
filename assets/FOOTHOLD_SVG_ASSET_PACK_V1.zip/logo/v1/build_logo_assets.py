#!/usr/bin/env python3
"""Generate the FOOTHOLD v1 vector asset pack from one geometry and token source."""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from pathlib import Path

from fontTools.pens.boundsPen import BoundsPen
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.ttLib import TTFont
from fontTools.varLib.instancer import instantiateVariableFont


SCRIPT = Path(__file__).resolve()
LOGO_DIR = SCRIPT.parent
BRAND_DIR = SCRIPT.parents[3]
EXPORT_DIR = BRAND_DIR / "assets" / "exports" / "v1"
TOKEN_PATH = BRAND_DIR / "tokens" / "foothold.tokens.json"

BAHNSCHRIFT = Path(r"C:\Windows\Fonts\bahnschrift.ttf")
SEGOE_SEMIBOLD = Path(r"C:\Windows\Fonts\seguisb.ttf")
NOTO_KR = Path(r"C:\Windows\Fonts\NotoSansKR-VF.ttf")

SUBTITLE = "TERRAIN-ADAPTIVE LOCOMOTION POLICY"
TAGLINE_KO = "사람이 먼저 밟아볼 수 없는 땅을, 로봇이 넘어지지 않고 건너가게 만듭니다."

SYMBOL_PATHS = (
    "M41 8 74 33v13L41 24 8 46V33z",
    "m35 37-27 18v14l27-18z",
    "m47 37 27 18v14L47 52z",
    "m33 66 8 6 8-6 9 8-17 12-17-12z",
)
CONTACT_PATH = "m9 4 12 9L33 4l9 8-21 15L0 12z"


def token_colours() -> tuple[dict[str, str], dict[str, str]]:
    data = json.loads(TOKEN_PATH.read_text(encoding="utf-8"))
    p = data["primitive"]["color"]

    def light(name: str) -> str:
        return p[name]["$value"]

    def dark(name: str) -> str:
        return p[name]["$extensions"]["foothold"]["mode"]["dark"]

    light_mode = {
        "paper": light("paper"),
        "paper2": light("paper-secondary"),
        "card": light("card"),
        "ink": light("ink"),
        "ink2": light("ink-secondary"),
        "ink3": light("ink-caption"),
        "rule": light("rule"),
        "brand": light("teal-brand"),
        "grid": light("grid"),
    }
    dark_mode = {
        "paper": dark("paper"),
        "paper2": dark("paper-secondary"),
        "card": dark("card"),
        "ink": dark("ink"),
        "ink2": dark("ink-secondary"),
        "ink3": dark("ink-caption"),
        "rule": dark("rule"),
        "brand": dark("teal-brand"),
        "grid": dark("grid"),
    }
    return light_mode, dark_mode


LIGHT, DARK = token_colours()


def load_font(path: Path, axes: dict[str, float] | None = None) -> TTFont:
    font = TTFont(path)
    if axes and "fvar" in font:
        available = {axis.axisTag for axis in font["fvar"].axes}
        selected = {key: value for key, value in axes.items() if key in available}
        if selected:
            font = instantiateVariableFont(font, selected, inplace=False)
    return font


# The A.3 review board was approved with a 750 x 95.6484375 visible
# wordmark box.  Vector export must preserve that approved silhouette instead
# of falling back to the font's natural width.
APPROVED_WORDMARK_ASPECT = 750 / 95.6484375
WORD_FONT = load_font(BAHNSCHRIFT, {"wght": 700, "wdth": 100})
SUBTITLE_FONT = load_font(SEGOE_SEMIBOLD)
KOREAN_FONT = load_font(NOTO_KR, {"wght": 600})


@dataclass(frozen=True)
class Outline:
    path: str
    x_min: float
    y_min: float
    x_max: float
    y_max: float
    advance: float

    @property
    def width(self) -> float:
        return self.x_max - self.x_min

    @property
    def height(self) -> float:
        return self.y_max - self.y_min


def outline_text(font: TTFont, text: str, tracking: float = 0) -> Outline:
    glyph_set = font.getGlyphSet()
    cmap = font.getBestCmap()
    metrics = font["hmtx"].metrics
    svg_pen = SVGPathPen(glyph_set)
    bounds_pen = BoundsPen(glyph_set)
    x = 0.0

    for index, char in enumerate(text):
        glyph_name = cmap.get(ord(char), ".notdef")
        glyph = glyph_set[glyph_name]
        glyph.draw(TransformPen(svg_pen, (1, 0, 0, 1, x, 0)))
        glyph.draw(TransformPen(bounds_pen, (1, 0, 0, 1, x, 0)))
        x += metrics[glyph_name][0]
        if index < len(text) - 1:
            x += tracking

    if bounds_pen.bounds is None:
        raise ValueError(f"No outline generated for {text!r}")
    x_min, y_min, x_max, y_max = bounds_pen.bounds
    return Outline(svg_pen.getCommands(), x_min, y_min, x_max, y_max, x)


WORD = outline_text(WORD_FONT, "FOOTHOLD", tracking=28)
KOREAN = outline_text(KOREAN_FONT, TAGLINE_KO)
WORD_NATURAL_ASPECT = WORD.width / WORD.height
WORD_X_STRETCH = APPROVED_WORDMARK_ASPECT / WORD_NATURAL_ASPECT


def scale_for_height(outline: Outline, visual_height: float) -> float:
    return visual_height / outline.height


def visual_width(outline: Outline, visual_height: float) -> float:
    return outline.width * scale_for_height(outline, visual_height)


def fit_tracking(font: TTFont, text: str, visual_height: float, target_width: float) -> Outline:
    low, high = -200.0, 12000.0
    for _ in range(42):
        middle = (low + high) / 2
        candidate = outline_text(font, text, middle)
        width = visual_width(candidate, visual_height)
        if width < target_width:
            low = middle
        else:
            high = middle
    return outline_text(font, text, (low + high) / 2)


def path_group(
    outline: Outline,
    x: float,
    baseline: float,
    visual_height: float,
    colour: str,
    skew: float = 0,
    opacity: float = 1,
    x_stretch: float = 1,
) -> str:
    scale = scale_for_height(outline, visual_height)
    skew_group = f'<g transform="skewX({skew:g})">' if skew else "<g>"
    return (
        f'<g fill="{colour}" opacity="{opacity:g}" transform="translate({x:g} {baseline:g})">'
        f'{skew_group}<g transform="scale({scale * x_stretch:.8f} {-scale:.8f})">'
        f'<g transform="translate({-outline.x_min:.6f} 0)"><path d="{outline.path}"/></g>'
        "</g></g></g>"
    )


def symbol_group(x: float, y: float, height: float, colour: str, opacity: float = 1) -> str:
    scale = height / 94
    paths = "".join(f'<path d="{path}"/>' for path in SYMBOL_PATHS)
    return (
        f'<g fill="{colour}" opacity="{opacity:g}" '
        f'transform="translate({x:g} {y:g}) scale({scale:.8f})">{paths}</g>'
    )


def contact_group(x: float, y: float, width: float, colour: str, opacity: float = 1) -> str:
    scale = width / 42
    return (
        f'<g fill="{colour}" opacity="{opacity:g}" '
        f'transform="translate({x:g} {y:g}) scale({scale:.8f})"><path d="{CONTACT_PATH}"/></g>'
    )


def grid_defs(grid_colour: str) -> str:
    return (
        '<pattern id="grid" width="32" height="32" patternUnits="userSpaceOnUse">'
        f'<path d="M32 0H0V32" fill="none" stroke="{grid_colour}" stroke-width="1"/>'
        "</pattern>"
    )


def svg_doc(width: float, height: float, body: str, title: str, desc: str, defs: str = "") -> str:
    return (
        f'<svg xmlns="http://www.w3.org/2000/svg" width="{width:g}" height="{height:g}" '
        f'viewBox="0 0 {width:g} {height:g}" role="img" aria-labelledby="title desc">'
        f'<title id="title">{title}</title><desc id="desc">{desc}</desc>'
        f'<defs>{defs}</defs>{body}</svg>\n'
    )


def canvas(width: float, height: float, mode: dict[str, str]) -> str:
    return (
        f'<rect width="{width:g}" height="{height:g}" fill="{mode["paper"]}"/>'
        '<rect width="100%" height="100%" fill="url(#grid)"/>'
    )


def write_svg(path: Path, svg: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(svg, encoding="utf-8", newline="\n")


def wordmark_width(cap_height: float) -> float:
    return APPROVED_WORDMARK_ASPECT * cap_height


def wordmark_group(x: float, baseline: float, cap_height: float, colour: str) -> str:
    return path_group(WORD, x, baseline, cap_height, colour, skew=-3, x_stretch=WORD_X_STRETCH)


def wordmark_geometry(cap_height: float, colour: str, x: float = 0, baseline: float | None = None) -> tuple[str, float, float]:
    baseline = cap_height + 4 if baseline is None else baseline
    width = wordmark_width(cap_height)
    return wordmark_group(x, baseline, cap_height, colour), width, baseline


def subtitle_geometry(x: float, baseline: float, cap_height: float, target_width: float, colour: str) -> str:
    fitted = fit_tracking(SUBTITLE_FONT, SUBTITLE, cap_height, target_width)
    return path_group(fitted, x, baseline, cap_height, colour)


def primary_lockup(mode: dict[str, str]) -> tuple[float, float, str]:
    cap_height = 86
    word_x, word_baseline = 180, 106
    word = wordmark_group(word_x, word_baseline, cap_height, mode["ink"])
    word_width = wordmark_width(cap_height)
    subtitle = subtitle_geometry(word_x, 158, 11.5, word_width, mode["ink2"])
    symbol = symbol_group(0, 0, 165, mode["brand"])
    width, height = word_x + word_width + 14, 180
    return width, height, symbol + word + subtitle


def compact_lockup(mode: dict[str, str]) -> tuple[float, float, str]:
    cap_height = 56
    word_x, word_baseline = 76, 72
    word_width = wordmark_width(cap_height)
    symbol = symbol_group(0, 5, 80, mode["brand"])
    word = wordmark_group(word_x, word_baseline, cap_height, mode["ink"])
    return word_x + word_width + 10, 96, symbol + word


def stacked_lockup(mode: dict[str, str]) -> tuple[float, float, str]:
    width, height = 600, 600
    word_cap = 62
    word_width = wordmark_width(word_cap)
    word_x = (width - word_width) / 2
    subtitle_cap = 10.5
    symbol_height = 220
    symbol_width = symbol_height * 82 / 94
    symbol_x = (width - symbol_width) / 2
    body = symbol_group(symbol_x, 44, symbol_height, mode["brand"])
    body += wordmark_group(word_x, 375, word_cap, mode["ink"])
    body += subtitle_geometry(word_x, 430, subtitle_cap, word_width, mode["ink2"])
    return width, height, body


def contact_trail(mode: dict[str, str], x: float, y: float, width: float, opacity: float = 1) -> str:
    height = width * 160 / 900
    sx, sy = width / 900, height / 160
    path = (
        f'<path d="M30 132c142-96 268 18 404-70 119-77 252 12 406-48" '
        f'fill="none" stroke="{mode["rule"]}" stroke-width="3" stroke-dasharray="10 10"/>'
        + contact_group(22, 100, 70, mode["brand"], .28)
        + contact_group(238, 56, 78, mode["brand"], .48)
        + contact_group(486, 78, 86, mode["brand"], .72)
        + contact_group(758, 10, 98, mode["brand"], 1)
    )
    return f'<g opacity="{opacity:g}" transform="translate({x:g} {y:g}) scale({sx:.8f} {sy:.8f})">{path}</g>'


def korean_line(x: float, baseline: float, visual_height: float, colour: str) -> tuple[str, float]:
    return path_group(KOREAN, x, baseline, visual_height, colour), visual_width(KOREAN, visual_height)


def export_core_assets() -> list[dict[str, object]]:
    manifest: list[dict[str, object]] = []

    def add(name: str, width: float, height: float, body: str, purpose: str) -> None:
        path = LOGO_DIR / name
        write_svg(path, svg_doc(width, height, body, name.removesuffix(".svg"), purpose))
        manifest.append({"path": str(path.relative_to(BRAND_DIR)).replace("\\", "/"), "width": round(width, 3), "height": round(height, 3), "purpose": purpose})

    add("foothold-symbol-brand.svg", 82, 94, symbol_group(0, 0, 94, LIGHT["brand"]), "Primary standalone FOOTHOLD symbol.")
    add("foothold-symbol-ink.svg", 82, 94, symbol_group(0, 0, 94, LIGHT["ink"]), "Single-colour symbol for print and embossing.")
    add("foothold-symbol-reverse.svg", 82, 94, symbol_group(0, 0, 94, DARK["ink"]), "Reverse symbol for dark surfaces.")

    word_cap = 90
    word_width = wordmark_width(word_cap)
    add("foothold-wordmark-ink.svg", word_width + 8, 110, wordmark_group(0, 100, word_cap, LIGHT["ink"]), "FOOTHOLD wordmark only, outlined and font-independent.")
    add("foothold-wordmark-reverse.svg", word_width + 8, 110, wordmark_group(0, 100, word_cap, DARK["ink"]), "Reverse FOOTHOLD wordmark only.")

    for suffix, mode in (("light", LIGHT), ("dark", DARK)):
        width, height, body = primary_lockup(mode)
        add(f"foothold-lockup-primary-{suffix}.svg", width, height, body, f"Primary two-row horizontal lockup for {suffix} surfaces.")
        width, height, body = compact_lockup(mode)
        add(f"foothold-lockup-compact-{suffix}.svg", width, height, body, f"Compact one-row lockup for {suffix} surfaces and small sizes.")
        width, height, body = stacked_lockup(mode)
        add(f"foothold-lockup-stacked-{suffix}.svg", width, height, body, f"Stacked lockup for square and centred compositions on {suffix} surfaces.")

    mono_mode = dict(LIGHT)
    mono_mode.update({"brand": LIGHT["ink"], "ink": LIGHT["ink"], "ink2": LIGHT["ink"]})
    width, height, body = primary_lockup(mono_mode)
    add("foothold-lockup-primary-monochrome.svg", width, height, body, "Single-ink primary lockup for print, engraving, and embroidery.")

    favicon_body = '<rect width="96" height="96" rx="18" fill="#f6f5f1"/>' + symbol_group(7, 1, 94, LIGHT["brand"])
    add("foothold-favicon.svg", 96, 96, favicon_body, "Square favicon and app-icon source.")

    trail_body = contact_trail(LIGHT, 0, 0, 900)
    add("foothold-contact-trail.svg", 900, 160, trail_body, "Secondary four-contact trail; never use as the primary logo.")
    return manifest


def export_derivatives(manifest: list[dict[str, object]]) -> None:
    def add(relative: str, width: float, height: float, body: str, purpose: str, defs: str = "") -> None:
        path = EXPORT_DIR / relative
        write_svg(path, svg_doc(width, height, body, Path(relative).stem, purpose, defs))
        manifest.append({"path": str(path.relative_to(BRAND_DIR)).replace("\\", "/"), "width": width, "height": height, "purpose": purpose})

    # Web brand headers. Navigation remains HTML rather than baked into the image.
    for suffix, mode in (("light", LIGHT), ("dark", DARK)):
        compact_w, compact_h, compact_body = compact_lockup(mode)
        body = canvas(1200, 160, mode)
        body += f'<g transform="translate(64 32)">{compact_body}</g>'
        body += contact_trail(mode, 790, 40, 350, .55)
        add(f"web/foothold-web-header-{suffix}.svg", 1200, 160, body, f"Web header brand strip for {suffix} mode; pair with live HTML navigation.", grid_defs(mode["grid"]))

    # README hero variants.
    for suffix, mode in (("light", LIGHT), ("dark", DARK)):
        primary_w, primary_h, primary_body = primary_lockup(mode)
        body = canvas(1280, 440, mode)
        body += f'<g transform="translate(64 48)">{primary_body}</g>'
        tagline, tagline_width = korean_line(72, 352, 27, mode["ink"])
        body += tagline
        body += contact_trail(mode, 810, 300, 410, .62)
        add(f"github/foothold-readme-hero-{suffix}.svg", 1280, 440, body, f"GitHub README hero for {suffix} mode with the canonical Korean definition.", grid_defs(mode["grid"]))

    # GitHub social preview uses dark mode for strong thumbnail contrast.
    mode = DARK
    body = canvas(1280, 640, mode)
    body += symbol_group(72, 84, 300, mode["brand"])
    word_cap = 100
    word_width = wordmark_width(word_cap)
    body += wordmark_group(390, 285, word_cap, mode["ink"])
    body += subtitle_geometry(390, 352, 13.5, word_width, mode["ink2"])
    tagline, _ = korean_line(390, 458, 24, mode["ink"])
    body += tagline
    body += contact_trail(mode, 650, 500, 560, .7)
    add("github/foothold-github-social-preview.svg", 1280, 640, body, "GitHub repository social preview in the FOOTHOLD dark theme.", grid_defs(mode["grid"]))

    # GitHub/avatar utility images.
    for suffix, mode in (("light", LIGHT), ("dark", DARK)):
        body = canvas(512, 512, mode) + symbol_group(94, 56, 400, mode["brand"])
        add(f"github/foothold-avatar-{suffix}.svg", 512, 512, body, f"GitHub and profile avatar for {suffix} mode.", grid_defs(mode["grid"]))

    # 16:9 presentation opening.
    mode = LIGHT
    primary_w, primary_h, primary_body = primary_lockup(mode)
    body = canvas(1920, 1080, mode)
    body += f'<g transform="translate(160 190) scale(1.55)">{primary_body}</g>'
    tagline, _ = korean_line(166, 710, 41, mode["ink"])
    body += tagline
    body += contact_trail(mode, 780, 790, 1000, .72)
    add("presentation/foothold-opening-slide-16x9.svg", 1920, 1080, body, "16:9 FOOTHOLD opening-slide brand composition.", grid_defs(mode["grid"]))

    # Poster header module.
    primary_w, primary_h, primary_body = primary_lockup(LIGHT)
    body = canvas(1400, 460, LIGHT)
    body += f'<g transform="translate(54 34) scale(1.35)">{primary_body}</g>'
    tagline, _ = korean_line(62, 400, 27, LIGHT["ink"])
    body += tagline
    add("poster/foothold-poster-header.svg", 1400, 460, body, "Poster and roll-up brand header module.", grid_defs(LIGHT["grid"]))

    # Social square.
    stacked_w, stacked_h, stacked_body = stacked_lockup(DARK)
    body = canvas(1080, 1080, DARK)
    body += f'<g transform="translate(240 120)">{stacked_body}</g>'
    tagline, tagline_width = korean_line(0, 920, 28, DARK["ink"])
    body += f'<g transform="translate({(1080 - tagline_width) / 2:.4f} 0)">{tagline}</g>'
    add("social/foothold-social-square.svg", 1080, 1080, body, "Square social and portfolio cover using the stacked lockup.", grid_defs(DARK["grid"]))

    # Round sticker / goods mark.
    stacked_w, stacked_h, stacked_body = stacked_lockup(LIGHT)
    body = '<circle cx="400" cy="400" r="384" fill="#f6f5f1" stroke="#0e7a6e" stroke-width="12"/>'
    body += f'<g transform="translate(100 92)">{stacked_body}</g>'
    add("goods/foothold-sticker-round.svg", 800, 800, body, "Round sticker and goods source with the stacked lockup.")


def preview_board(manifest: list[dict[str, object]]) -> None:
    cards = [
        ("SYMBOL", "../../logo/v1/foothold-symbol-brand.svg", 100, 190, 520, 320, LIGHT["card"]),
        ("WORDMARK", "../../logo/v1/foothold-wordmark-ink.svg", 680, 190, 760, 320, LIGHT["card"]),
        ("PRIMARY", "../../logo/v1/foothold-lockup-primary-light.svg", 1500, 190, 800, 320, LIGHT["card"]),
        ("COMPACT", "../../logo/v1/foothold-lockup-compact-light.svg", 100, 600, 700, 300, LIGHT["card"]),
        ("STACKED", "../../logo/v1/foothold-lockup-stacked-light.svg", 860, 600, 520, 520, LIGHT["card"]),
        ("REVERSE", "../../logo/v1/foothold-lockup-primary-dark.svg", 1440, 600, 860, 300, DARK["paper"]),
        ("WEB HEADER", "web/foothold-web-header-light.svg", 100, 1190, 1050, 300, LIGHT["card"]),
        ("README HERO", "github/foothold-readme-hero-dark.svg", 1250, 1190, 1050, 360, DARK["paper"]),
        ("SOCIAL", "social/foothold-social-square.svg", 100, 1590, 620, 620, DARK["paper"]),
        ("STICKER", "goods/foothold-sticker-round.svg", 790, 1590, 620, 620, LIGHT["card"]),
        ("16:9 OPENING", "presentation/foothold-opening-slide-16x9.svg", 1480, 1590, 820, 460, LIGHT["card"]),
    ]
    width, height = 2400, 2280
    defs = grid_defs(LIGHT["grid"])
    body = canvas(width, height, LIGHT)
    body += '<text x="100" y="86" font-family="Segoe UI,Arial,sans-serif" font-size="20" font-weight="700" letter-spacing="4" fill="#0e7a6e">FOOTHOLD / SVG ASSET PACK / V1</text>'
    body += '<text x="100" y="142" font-family="Segoe UI,Arial,sans-serif" font-size="42" font-weight="700" fill="#161c26">One vector source, composed for every surface.</text>'
    for label, href, x, y, w, h, fill in cards:
        body += f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="22" fill="{fill}" stroke="#d9d6cd"/>'
        body += f'<text x="{x + 26}" y="{y + 38}" font-family="Consolas,monospace" font-size="14" font-weight="700" letter-spacing="2" fill="#7c8798">{label}</text>'
        body += f'<image href="{href}" x="{x + 26}" y="{y + 58}" width="{w - 52}" height="{h - 84}" preserveAspectRatio="xMidYMid meet"/>'
    path = EXPORT_DIR / "FOOTHOLD_ASSET_PACK_V1_PREVIEW.svg"
    write_svg(path, svg_doc(width, height, body, "FOOTHOLD SVG asset pack v1 preview", "Preview sheet for the complete FOOTHOLD vector asset pack.", defs))
    manifest.append({"path": str(path.relative_to(BRAND_DIR)).replace("\\", "/"), "width": width, "height": height, "purpose": "Visual index of the complete SVG asset pack."})


def write_manifest(manifest: list[dict[str, object]]) -> None:
    for item in manifest:
        path = BRAND_DIR / str(item["path"])
        item["sha256"] = hashlib.sha256(path.read_bytes()).hexdigest()
    payload = {
        "name": "FOOTHOLD SVG Asset Pack",
        "version": "1.0.1",
        "approvedWordmarkAspect": round(APPROVED_WORDMARK_ASPECT, 9),
        "wordmarkCorrection": "Preserves the approved A.3 wordmark width-to-height proportion.",
        "generatedFrom": [
            "tokens/foothold.tokens.json",
            "assets/logo/v1/build_logo_assets.py",
        ],
        "fontDependency": "None in generated SVGs; all logo and message text is outlined.",
        "assets": manifest,
    }
    (EXPORT_DIR / "manifest.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main() -> None:
    manifest = export_core_assets()
    export_derivatives(manifest)
    preview_board(manifest)
    write_manifest(manifest)
    print(f"Generated {len(manifest)} SVG assets")
    print(f"Core: {LOGO_DIR}")
    print(f"Derived: {EXPORT_DIR}")


if __name__ == "__main__":
    main()
